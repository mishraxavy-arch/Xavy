# XAVY — Android video editor prototype

A starter Android Studio project for a CapCut-inspired editor.

## Features in this prototype
- Import a video using Android's file picker
- Preview the selected video
- Set start/end trim points
- Export the selected range as an MP4

## Build an APK using only your Android phone
This project includes a GitHub Actions workflow so you can build the APK in the cloud without installing Android Studio.

1. Sign in to GitHub in your phone browser and create a **new public or private repository** named `xavy`.
2. Upload the contents of this ZIP into the repository. Make sure `.github/workflows/android.yml` is included. (If your file picker hides folders beginning with a dot, create `.github/workflows` in GitHub's web interface and add `android.yml` there.)
3. Open the repository's **Actions** tab and enable Actions if GitHub asks.
4. The workflow starts after you push to the `main` branch. You can also open **Build XAVY APK** and tap **Run workflow**.
5. Wait for the workflow to finish successfully.
6. Open that completed workflow run, scroll to **Artifacts**, and download `XAVY-debug-apk`.
7. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install. Android may ask you to allow installs from your browser or file manager; only allow this for the APK you built from your own repository.

## Important
- This is an early prototype, not a finished CapCut replacement.
- Audio mixing, multi-track editing, text overlays, filters, transitions, project saving and gallery export are not implemented yet.
- The APK is a debug build for testing, not a Play Store release.
- Exports are stored in the app's private external files folder for now.
