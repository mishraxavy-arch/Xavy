package com.example.cutstudio

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.util.Locale

private val Ink = Color(0xFF111318)
private val Panel = Color(0xFF1B1E25)
private val Accent = Color(0xFFB7F36B)
private val Muted = Color(0xFF9298A4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(17, 19, 24)
        window.navigationBarColor = android.graphics.Color.rgb(17, 19, 24)
        setContent { CutStudioScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CutStudioScreen() {
    val context = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var playhead by remember { mutableFloatStateOf(0f) }
    var trimStart by remember { mutableFloatStateOf(0f) }
    var trimEnd by remember { mutableFloatStateOf(1f) }
    var exporting by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Import a video to start editing") }
    var player by remember { mutableStateOf<ExoPlayer?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            videoUri = uri
            playhead = 0f
            trimStart = 0f
            trimEnd = 1f
            status = "Video loaded — set your trim range"
        }
    }

    DisposableEffect(videoUri) {
        val uri = videoUri
        if (uri != null) {
            val exo = ExoPlayer.Builder(context).build()
            exo.setMediaItem(MediaItem.fromUri(uri))
            exo.prepare()
            exo.playWhenReady = false
            exo.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) {
                        durationMs = exo.duration.coerceAtLeast(0L)
                    }
                }
            })
            player = exo
        } else {
            player = null
        }
        onDispose { player?.release(); player = null }
    }

    val durationSeconds = durationMs / 1000f
    val startMs = (trimStart * durationMs).toLong()
    val endMs = (trimEnd * durationMs).toLong().coerceAtLeast(startMs + 500L)

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink, surface = Panel, primary = Accent,
            onPrimary = Ink, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(containerColor = Ink, topBar = {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("CUTSTUDIO", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("Video editor", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = { exportVideo(context, videoUri, startMs, endMs, { exporting = true; status = "Exporting video…" }, { message -> exporting = false; status = message; Toast.makeText(context, message, Toast.LENGTH_LONG).show() }) },
                    enabled = videoUri != null && !exporting,
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink),
                    shape = RoundedCornerShape(12.dp)
                ) { if (exporting) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp, color = Ink) else Text("Export", fontWeight = FontWeight.Bold) }
            }
        }) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    Modifier.fillMaxWidth().weight(1f).background(Color(0xFF08090C), RoundedCornerShape(18.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (videoUri != null && player != null) {
                        AndroidView(
                            factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
                            update = { it.player = player },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(Icons.Default.Movie, null, tint = Muted, modifier = Modifier.size(48.dp))
                            Text("Your preview appears here", color = Muted)
                            Button(onClick = { picker.launch(arrayOf("video/*")) }, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink)) {
                                Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add video")
                            }
                        }
                    }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("TIMELINE", color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Text(if (durationMs > 0) formatTime(durationMs) else "00:00", color = Muted, fontSize = 12.sp)
                }
                Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ContentCut, null, tint = Accent)
                        Spacer(Modifier.width(8.dp))
                        Text("Trim clip", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.weight(1f))
                        Text("${formatTime(startMs)} – ${formatTime(endMs)}", color = Muted, fontSize = 12.sp)
                    }
                    Text("Start", color = Muted, fontSize = 12.sp)
                    Slider(value = trimStart, onValueChange = { v -> trimStart = v.coerceAtMost(trimEnd - 0.02f) }, valueRange = 0f..0.98f, enabled = videoUri != null, colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent))
                    Text("End", color = Muted, fontSize = 12.sp)
                    Slider(value = trimEnd, onValueChange = { v -> trimEnd = v.coerceAtLeast(trimStart + 0.02f) }, valueRange = 0.02f..1f, enabled = videoUri != null, colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent))
                }

                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    item { ToolChip("Audio", Icons.Default.MusicNote, false) }
                    item { ToolChip("Filters", Icons.Default.Tune, false) }
                    item { ToolChip("Split", Icons.Default.ContentCut, false) }
                    item { ToolChip("Add clip", Icons.Default.Add, true) { picker.launch(arrayOf("video/*")) } }
                }
                Text(status, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
            }
        }
    }
}

@Composable
private fun ToolChip(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, active: Boolean, onClick: (() -> Unit)? = null) {
    Surface(
        color = if (active) Accent.copy(alpha = 0.16f) else Panel,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = if (active) Accent else Muted, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(7.dp))
            Text(label, color = Color.White, fontSize = 13.sp)
        }
    }
}

private fun formatTime(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) / 1000).toInt()
    return String.format(Locale.US, "%02d:%02d", total / 60, total % 60)
}

private fun exportVideo(
    context: android.content.Context,
    uri: Uri?,
    startMs: Long,
    endMs: Long,
    onStart: () -> Unit,
    onFinish: (String) -> Unit
) {
    if (uri == null) return
    try {
        val outputDir = File(context.getExternalFilesDir(null), "exports").apply { mkdirs() }
        val output = File(outputDir, "CutStudio_${System.currentTimeMillis()}.mp4")
        val clippedItem = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(endMs)
                    .build()
            ).build()
        val edited = EditedMediaItem.Builder(clippedItem).build()
        val transformer = Transformer.Builder(context)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                    onFinish("Export complete: ${output.absolutePath}")
                }
                override fun onError(composition: androidx.media3.transformer.Composition, exportResult: ExportResult, exportException: ExportException) {
                    onFinish("Export failed: ${exportException.message ?: "Unknown error"}")
                }
            }).build()
        onStart()
        transformer.start(edited, output.absolutePath)
    } catch (e: Exception) {
        onFinish("Could not export: ${e.message}")
    }
}
